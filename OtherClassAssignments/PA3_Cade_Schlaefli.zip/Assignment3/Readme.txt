Readme:
Relatively straightforward GUI, save/load under files opens a dialog for file locations 
save files is a simple formatted binary with no file extensions, there's a sample file called "asdf" in the project folder
Toggle hiding completed taks can be done through the view menu dropdown
Priority format is any positive or negative integer, because that's how process priority is handled in linux

Should build simply in VS2018 from the solution file.